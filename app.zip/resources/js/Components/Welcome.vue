<script setup>
</script>

<template>
    <h1>Hello World</h1>
</template>