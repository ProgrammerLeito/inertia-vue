<script setup>
import { Link } from '@inertiajs/vue3';
</script>

<template>
    <Link :href="'/'">
        <img class="w-48 h-48" src="../../../public/img/social-media-2.png"/>
    </Link>
</template>
